﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace WiMSAPI.Areas.Upload.Models
{
    public class SO : IDisposable
    {
        #region private properties
        private static readonly SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int? RequestId { get; set; }
        public string StorerKey { get; set; }
        public short? WHId { get; set; }
        //public short? SOTemplateId { get; set; }        
        public string ExternalOrderNo { get; set; }
        public string BuyerPO { get; set; }
        public string OrderGroup { get; set; }
        public string ShipTo { get; set; }
        public string BillTo { get; set; }
        public string DeliveryDate { get; set; }
        public string UDF1 { get; set; }
        public string UDF2 { get; set; }
        public string UDF3 { get; set; }
        public string UDF4 { get; set; }
        public string UDF5 { get; set; }
        public List<SODetail> Details { get; set; } = new List<SODetail>();   
        #endregion

        #region constructor
        public SO()
        {
        }
        #endregion

        #region internal methods
        internal static bool Save(List<SO> sos, string userId)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    foreach (SO so in sos)
                    {
                        DbCommand dbCommand = db.GetStoredProcCommand("SaveUploadOrder");
                        db.AddInParameter(dbCommand, "StorerKey", SqlDbType.VarChar, so.StorerKey);
                        db.AddInParameter(dbCommand, "WarehouseId", SqlDbType.SmallInt, so.WHId);
                        db.AddInParameter(dbCommand, "CustomerOrderNo", SqlDbType.VarChar, so.ExternalOrderNo);
                        db.AddInParameter(dbCommand, "ConsigneeKey", SqlDbType.VarChar, so.ShipTo);
                        db.AddInParameter(dbCommand, "PO", SqlDbType.VarChar, so.BuyerPO);
                        db.AddInParameter(dbCommand, "OrderGroup", SqlDbType.VarChar, so.OrderGroup);
                        db.AddInParameter(dbCommand, "BillToKey", SqlDbType.VarChar, so.BillTo);
                        if (so.DeliveryDate.ToString().Trim() != string.Empty)
                        {
                            db.AddInParameter(dbCommand, "DeliveryDate", SqlDbType.DateTime, Convert.ToDateTime(so.DeliveryDate));
                        }
                        db.AddInParameter(dbCommand, "UDF1", SqlDbType.VarChar, so.UDF1.ToString());
                        db.AddInParameter(dbCommand, "UDF2", SqlDbType.VarChar, so.UDF2.ToString());
                        db.AddInParameter(dbCommand, "UDF3", SqlDbType.VarChar, so.UDF3.ToString());
                        db.AddInParameter(dbCommand, "UDF4", SqlDbType.VarChar, so.UDF4.ToString());
                        db.AddInParameter(dbCommand, "UDF5", SqlDbType.VarChar, so.UDF5.ToString());
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, userId);
                        db.AddOutParameter(dbCommand, "NewRequestId", SqlDbType.Int, 32);
                        db.ExecuteNonQuery(dbCommand, transaction);
                        int requestId = Convert.ToInt32(dbCommand.Parameters["@NewRequestId"].Value);
                        SODetail.Save(requestId, so.Details, transaction);
                        markComplete(requestId, transaction);
                    }
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        #endregion

        #region private methods
        private static bool markComplete(int requestId, DbTransaction transaction)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("CompleteSO"))
                {
                    db.AddInParameter(dbCommand, "RequestId", SqlDbType.Int, requestId);
                    db.ExecuteNonQuery(dbCommand, transaction);
                    return true;
                }
            }
            catch (Exception) { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
        }
        #endregion
    }
}