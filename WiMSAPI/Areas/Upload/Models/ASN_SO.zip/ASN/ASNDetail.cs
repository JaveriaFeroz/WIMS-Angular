﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Runtime.Serialization;

namespace WiMSAPI.Areas.Upload.Models
{
    [DataContract]
    public class ASNDetail : IDisposable
    {
        #region private properties
        private static readonly SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public string SKU { get; set; }
        public decimal Quantity { get; set; }
        public string Lottable01 { get; set; }
        public string Lottable02 { get; set; }
        public string Lottable03 { get; set; }
        public string Lottable04 { get; set; }
        public string Lottable05 { get; set; }
        public string Lottable06 { get; set; }
        public string Lottable07 { get; set; }
        public string Lottable08 { get; set; } 
        public string Lottable09 { get; set; } 
        public string Lottable10 { get; set; }
        #endregion

        #region constructor
        public ASNDetail()
        {
            
        }
        #endregion

        #region internal methods
        internal static bool Save(int requestId, List<ASNDetail> details, DbTransaction transaction)
        {
            try
            {
                foreach (ASNDetail asd in details)
                {
                    using (DbCommand dbCommand = db.GetStoredProcCommand("SaveUploadASNDetail"))
                    {
                        db.AddInParameter(dbCommand, "RequestId", SqlDbType.Int, requestId);
                        db.AddInParameter(dbCommand, "SKU", SqlDbType.VarChar, asd.SKU);
                        db.AddInParameter(dbCommand, "Quantity", SqlDbType.Decimal, asd.Quantity);
                        db.AddInParameter(dbCommand, "Lottable01", SqlDbType.VarChar, asd.Lottable01);
                        db.AddInParameter(dbCommand, "Lottable02", SqlDbType.VarChar, asd.Lottable02);
                        db.AddInParameter(dbCommand, "Lottable03", SqlDbType.VarChar, asd.Lottable03);
                        if (!string.IsNullOrWhiteSpace(asd.Lottable04.ToString()))
                        {
                            db.AddInParameter(dbCommand, "Lottable04", SqlDbType.DateTime, Convert.ToDateTime(asd.Lottable04));
                        }
                        if (!string.IsNullOrWhiteSpace(asd.Lottable05.ToString()))
                        {
                            db.AddInParameter(dbCommand, "Lottable05", SqlDbType.DateTime, Convert.ToDateTime(asd.Lottable05));
                        }
                        db.AddInParameter(dbCommand, "Lottable06", SqlDbType.VarChar, asd.Lottable06);
                        db.AddInParameter(dbCommand, "Lottable07", SqlDbType.VarChar, asd.Lottable07);
                        db.AddInParameter(dbCommand, "Lottable08", SqlDbType.VarChar, asd.Lottable08);
                        db.AddInParameter(dbCommand, "Lottable09", SqlDbType.VarChar, asd.Lottable09);
                        db.AddInParameter(dbCommand, "Lottable10", SqlDbType.VarChar, asd.Lottable10);
                        db.ExecuteNonQuery(dbCommand, transaction);
                    }
                }
                return true;
            }
            catch (Exception)
            { throw; }
        }
        #endregion

        #region IDisposable implementation
        public void Dispose()
        {
        }
        #endregion
    }
}