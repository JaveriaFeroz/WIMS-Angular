﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace WiMSAPI.Areas.Upload.Models
{
    public class ASN : IDisposable
    {
        #region private properties
        private static readonly SqlDatabase db = DatabaseFactory.CreateDatabase() as SqlDatabase;
        #endregion

        #region public properties
        public int? RequestId { get; set; }
        public string StorerKey { get; set; }
        public short? WHId { get; set; }
        public string RMANo { get; set; }
        public string ProNo { get; set; }
        public string CarrierRef { get; set; }
        public string ContainerKey { get; set; }
        public string WHRef { get; set; }
        public string CarrierKey { get; set; }
        public string UDF1 { get; set; }
        public string UDF2 { get; set; }
        public List<ASNDetail> Details { get; set; } = new List<ASNDetail>();
        #endregion

        #region constructor
        public ASN()
        {
        }
        #endregion

        #region internal methods
        internal static bool Save(List<ASN> asns, string userId)
        {
            using (DbConnection dbconnection = db.CreateConnection())
            {
                dbconnection.Open();
                DbTransaction transaction = dbconnection.BeginTransaction();
                try
                {
                    foreach (ASN asn in asns)
                    {
                        DbCommand dbCommand = db.GetStoredProcCommand("SaveUploadASN");
                        db.AddInParameter(dbCommand, "StorerKey", SqlDbType.VarChar, asn.StorerKey);
                        db.AddInParameter(dbCommand, "WarehouseId", SqlDbType.SmallInt, asn.WHId);
                        db.AddInParameter(dbCommand, "CustomerOrderNo", SqlDbType.VarChar, asn.ProNo);
                        db.AddInParameter(dbCommand, "RMA", SqlDbType.VarChar, asn.RMANo);
                        db.AddInParameter(dbCommand, "CarrierReference", SqlDbType.VarChar, asn.CarrierRef);
                        db.AddInParameter(dbCommand, "ContainerKey", SqlDbType.VarChar, asn.ContainerKey);
                        db.AddInParameter(dbCommand, "WarehouseReference", SqlDbType.VarChar, asn.WHRef);
                        db.AddInParameter(dbCommand, "CarrierKey", SqlDbType.VarChar, asn.CarrierKey);
                        db.AddInParameter(dbCommand, "SUSR1", SqlDbType.VarChar, asn.UDF1);
                        db.AddInParameter(dbCommand, "SUSR2", SqlDbType.VarChar, asn.UDF2);
                        db.AddInParameter(dbCommand, "UserId", SqlDbType.VarChar, userId);
                        db.AddOutParameter(dbCommand, "NewRequestId", SqlDbType.Int, 32);
                        db.ExecuteNonQuery(dbCommand, transaction);
                        int requestId = Convert.ToInt32(dbCommand.Parameters["@NewRequestId"].Value);
                        ASNDetail.Save(requestId, asn.Details, transaction);
                        markComplete(requestId, transaction);
                    }
                    transaction.Commit();
                    return true;
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }
        #endregion

        #region private methods
        private static bool markComplete(int requestId, DbTransaction transaction)
        {
            try
            {
                using (DbCommand dbCommand = db.GetStoredProcCommand("CompleteASN"))
                {
                    db.AddInParameter(dbCommand, "RequestId", SqlDbType.Int, requestId);
                    db.ExecuteNonQuery(dbCommand, transaction);
                    return true;
                }
            }
            catch (Exception) { throw; }
        }
        #endregion

        #region IDisposable Members
        public void Dispose()
        {
        }
        #endregion
    }
}