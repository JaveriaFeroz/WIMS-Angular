import { stDetail } from "./stdetail";

export class st {
  storerKey: string;
  whId: number;
  externalOrderNo: string;
  buyerPO: string;
  orderGroup: string;
  shipTo: string;
  billTo: string;
  deliveryDate: string;
  udf1: string;
  udf2: string;
  udf3: string;
  udf4: string;
  udf5: string;
  details: stDetail[] = [];   
}
