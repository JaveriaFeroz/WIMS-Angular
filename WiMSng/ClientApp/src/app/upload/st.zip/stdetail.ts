export class stDetail {
  sku: string;
  quantity: number;
  uom: string;
  lottable01: string;
  lottable02: string;
  lottable03: string;
  lottable04: string;
  lottable05: string;
  lottable06: string;
  lottable07: string;
  lottable08: string;
  lottable09: string;
  lottable10: string;
}   
