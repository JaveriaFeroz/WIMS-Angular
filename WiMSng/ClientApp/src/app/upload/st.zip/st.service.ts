import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { st } from './st';
@Injectable({ providedIn: 'root' })

export class stService {
  apiURL: string;
  constructor(private http: HttpClient, @Inject('API_BASE_URL') baseUrl: string) {
    this.apiURL = baseUrl;
  }

  getLookUp() {
    return this.http.get<any>(this.apiURL + 'upload/St/GetLookups');
  }

  save(st: st[]) {
    return this.http.post<st>(this.apiURL + 'upload/st/', st);
  }
}
