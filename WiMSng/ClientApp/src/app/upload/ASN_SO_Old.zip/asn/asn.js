"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ASN = void 0;
class ASN {
    constructor() {
        this.details = [];
    }
}
exports.ASN = ASN;
//# sourceMappingURL=asn.js.map