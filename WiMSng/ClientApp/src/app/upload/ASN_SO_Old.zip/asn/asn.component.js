"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ASNComponent = void 0;
const core_1 = require("@angular/core");
const forms_1 = require("@angular/forms");
const xlsx = require("xlsx");
const agFormHelper_1 = require("../../helper/agFormHelper");
const footer_1 = require("../../helper/footer");
const asn_1 = require("./asn");
const asndetail_1 = require("./asndetail");
let ASNComponent = class ASNComponent {
    //#endregion
    constructor(router, formbulider, svcASN, svcToaster, svcWaitDlg) {
        this.router = router;
        this.formbulider = formbulider;
        this.svcASN = svcASN;
        this.svcToaster = svcToaster;
        this.svcWaitDlg = svcWaitDlg;
        //#region form variables
        this.optionName = 'Advance Shipment Notice';
        this.errors = [];
        this.footer = new footer_1.agFooter();
    }
    ngOnInit() {
        this.frmASN = this.formbulider.group({
            whId: [null, [forms_1.Validators.required]],
            storerKey: [null, [forms_1.Validators.required]],
        });
        this.loadLookup();
        this.frmASN.disable();
        agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Initialize);
        document.getElementById("UploadFile").disabled = true;
    }
    //#region toolbar functions
    tbAdd() {
        this.frmASN.reset();
        this.frmASN.enable();
        agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Add);
        document.getElementById("UploadFile").disabled = false;
        this.whId.focus();
    }
    tbSave() {
        try {
            this.frmASN.markAllAsTouched();
            if (!this.frmASN.invalid) {
                var formData = this.frmASN.getRawValue();
                if (!formData.whId || !formData.storerKey) {
                    this.svcToaster.showFailure("Please select valid Warehouse and enter Storer Key before uploading the file!");
                }
                if (!this.wipDocument) {
                    this.svcToaster.showFailure("Please select valid file to be uploaded and then click Upload button");
                    return;
                }
                let fileReader = new FileReader();
                fileReader.onload = (e) => {
                    var arrayBuffer = fileReader.result;
                    var data = new Uint8Array(arrayBuffer);
                    var arr = new Array();
                    for (var i = 0; i != data.length; ++i)
                        arr[i] = String.fromCharCode(data[i]);
                    var bstr = arr.join("");
                    var workbook = xlsx.read(bstr, { type: "binary" });
                    var first_sheet_name = workbook.SheetNames[0];
                    var worksheet = workbook.Sheets[first_sheet_name];
                    let jsonData = xlsx.utils.sheet_to_json(worksheet, { raw: false, dateNF: "DD-MMM-YYYY", header: 1, defval: "" });
                    if (jsonData.length < 1) {
                        this.svcToaster.showFailure("No data found in your selected sheet, upload can't proceed further");
                        return;
                    }
                    this.validateHeader(jsonData[0]);
                    if (this.errors.length > 0) {
                        this.errors;
                        return;
                    }
                    else {
                        var asns = this.getData(formData.storerKey, formData.whId, jsonData, jsonData[0].length);
                        if (this.errors.length == 0)
                            this.validate(asns);
                        if (this.errors.length > 0) {
                            this.errors;
                            return;
                        }
                        else {
                            this.svcWaitDlg.open({});
                            this.svcASN.save(asns).subscribe(() => {
                                this.initForm();
                                agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Initialize);
                                this.svcToaster.showSuccess('Upload request(s) created Successfully');
                            }, error => { this.svcToaster.showFailure(error); }, () => { this.svcWaitDlg.close(); });
                        }
                    }
                };
                fileReader.readAsArrayBuffer(this.wipDocument);
            }
        }
        catch (e) {
            this.svcWaitDlg.close();
            this.svcToaster.showFailure(e);
        }
    }
    fileUpload(event) {
        this.wipDocument = event.target.files[0];
        if (!this.wipDocument) {
            this.svcToaster.showFailure("Please select valid file to be uploaded and then click Upload button");
            return;
        }
        if (this.wipDocument.size > 204800) {
            this.svcToaster.showFailure('Upload utility does not allow upload of file more than 200 KB. Please reduce file size and retry');
            return;
        }
    }
    tbUndo() {
        this.initForm();
        agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Initialize);
    }
    tbExit() {
        this.router.navigate(['/MainForm']);
    }
    //#endregion toolbar functions
    //#region local functions
    getData(storerKey, whId, jsonData, headerLength) {
        this.errors = [];
        var asns = [], proNumber = "", asn = new asn_1.ASN();
        for (let i = 1; i < jsonData.length; i++) {
            let currentRecord = jsonData[i];
            if (currentRecord.length == headerLength) {
                if (currentRecord[1].trim() == "") {
                    this.errors.push("row # " + (i + 1).toString() + " contains blank Pro Number, Pro number is a key field and can't be left blank, upload process failed!");
                    return;
                }
                if (proNumber != currentRecord[1].trim()) {
                    if (asn.details.length > 0) {
                        asns.push(asn);
                    }
                    asn = new asn_1.ASN();
                    asn.storerKey = storerKey;
                    asn.whId = whId;
                    proNumber = currentRecord[1].trim();
                    asn.rmaNo = currentRecord[0].trim();
                    asn.proNo = proNumber;
                    asn.carrierRef = currentRecord[2].trim();
                    asn.containerKey = currentRecord[3].trim();
                    asn.whRef = currentRecord[4].trim();
                    asn.carrierKey = currentRecord[5].trim();
                    asn.udf1 = currentRecord[6].trim();
                    asn.udf2 = currentRecord[7].trim();
                }
                let asd = new asndetail_1.ASNDetail();
                asd.sku = currentRecord[8].trim();
                asd.quantity = parseInt(currentRecord[9].trim());
                asd.lottable01 = currentRecord[10].trim();
                asd.lottable02 = currentRecord[11].trim();
                asd.lottable03 = currentRecord[12].trim();
                asd.lottable04 = currentRecord[13].trim();
                asd.lottable05 = currentRecord[14].trim();
                asd.lottable06 = currentRecord[15].trim();
                asd.lottable07 = currentRecord[16].trim();
                asd.lottable08 = currentRecord[17].trim();
                asd.lottable09 = currentRecord[18].trim();
                asd.lottable10 = currentRecord[19].trim();
                asn.details.push(asd);
            }
        }
        if (asn.details.length != 0)
            asns.push(asn);
        return asns;
    }
    loadLookup() {
        try {
            this.svcASN.getLookUp().subscribe(data => { this.lstWarehouse = data.lstWarehouse; }, error => { this.svcToaster.showFailure(error); });
        }
        catch (e) {
            this.svcToaster.showFailure(e);
        }
    }
    validate(asn) {
        this.errors = [];
        if (asn.some(x => x.proNo == "")) {
            this.errors.push('No row in ASN Upload can have empty PRO Number');
        }
        if (asn.some(y => y.details.some(x => x.sku == ""))) {
            this.errors.push('SKU is a required field and must be provided in each row of upload sheet');
        }
        if (asn.some(y => y.details.some(x => !x.quantity || x.quantity <= 0))) {
            this.errors.push('Quantity in each row must be greater than zero');
        }
    }
    validateHeader(header) {
        this.errors = [];
        if (header[0].trim() != "RMA Number") {
            this.errors.push('RMA Number is a required field. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings');
        }
        if (header[1].trim() != "Pro Number") {
            this.errors.push('Pro Number column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[2].trim() != "Carriers Ref") {
            this.errors.push('Carriers Ref column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[3].trim() != "Container Ref") {
            this.errors.push('Container Ref column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[4].trim() != "Warehouse Ref") {
            this.errors.push('Warehouse Ref column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[5].trim() != "Carrier") {
            this.errors.push('Carrier column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[6].trim() != "User1") {
            this.errors.push('User1 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[7].trim() != "User2") {
            this.errors.push('User2 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[8].trim() != "Commodity") {
            this.errors.push('Commodity column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[9].trim() != "Expected Qty") {
            this.errors.push('Expected Qty column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[10].trim() != "Lottable01") {
            this.errors.push('Lottable01 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[11].trim() != "Lottable02") {
            this.errors.push('Lottable02 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[12].trim() != "Lottable03") {
            this.errors.push('Lottable03 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[13].trim() != "Lottable04") {
            this.errors.push('Lottable04 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[14].trim() != "Lottable05") {
            this.errors.push('Lottable05 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[15].trim() != "Lottable06") {
            this.errors.push('Lottable06 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[16].trim() != "Lottable07") {
            this.errors.push('Lottable07 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[17].trim() != "Lottable08") {
            this.errors.push('Lottable08 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[18].trim() != "Lottable09") {
            this.errors.push('Lottable09 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[19].trim() != "Lottable10") {
            this.errors.push('Lottable10 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
    }
    initForm() {
        this.frmASN.reset();
        this.frmASN.disable();
        this.errors = [];
        document.getElementById("UploadFile").disabled = true;
        document.getElementById("UploadFile").value = null;
    }
};
__decorate([
    core_1.ViewChild('whId', { static: true })
], ASNComponent.prototype, "whId", void 0);
ASNComponent = __decorate([
    core_1.Component({
        selector: 'app-asn',
        templateUrl: './asn.component.html',
        styleUrls: ['./asn.component.css']
    })
], ASNComponent);
exports.ASNComponent = ASNComponent;
//# sourceMappingURL=asn.component.js.map