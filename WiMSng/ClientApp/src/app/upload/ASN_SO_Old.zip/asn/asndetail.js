"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ASNDetail = void 0;
class ASNDetail {
}
exports.ASNDetail = ASNDetail;
//# sourceMappingURL=asndetail.js.map