import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { ASN } from './asn';
@Injectable({ providedIn: 'root' })

export class ASNService {
  apiURL: string;
  constructor(private http: HttpClient, @Inject('API_BASE_URL') baseUrl: string) {
    this.apiURL = baseUrl;
  }

  getLookUp() {
    return this.http.get<any>(this.apiURL + 'upload/ASN/GetLookups');
  }

  save(asn: ASN[]) {
    return this.http.post<ASN[]>(this.apiURL + 'upload/ASN/', asn);
  }
}
