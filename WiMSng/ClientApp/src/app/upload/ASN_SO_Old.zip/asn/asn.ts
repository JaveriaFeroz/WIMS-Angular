import { ASNDetail } from "./asndetail";

export class ASN {
  storerKey: string;
  whId: number;
  rmaNo: string;
  proNo: string;
  carrierRef: string;
  containerKey: string;
  whRef : string;
  carrierKey: string;
  udf1: string;
  udf2: string;
  details: ASNDetail[] = [];   
}
