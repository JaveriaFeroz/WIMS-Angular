"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SODetail = void 0;
class SODetail {
}
exports.SODetail = SODetail;
//# sourceMappingURL=sodetail.js.map