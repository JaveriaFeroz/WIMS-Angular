import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSelect } from '@angular/material/select';
import { Router } from '@angular/router';
import * as xlsx from 'xlsx';
import { agFormHelper, agFormMode } from '../../helper/agFormHelper';
import { agFooter } from '../../helper/footer';
import { agToasterService } from '../../helper/service/toaster.service';
import { WaitDialogService } from '../../helper/waitDialog/wait-dialog.service';
import { SO } from './so';
import { SOService } from './so.service';
import { SODetail } from './sodetail';

@Component({
  selector: 'app-so',
  templateUrl: './so.component.html',
  styleUrls: ['./so.component.css']
})

export class SOComponent implements OnInit {
  //#region form variables
  readonly optionName: string = 'Shipment Order';
  frmSO: any;
  lstWarehouse: any;
  wipDocument: File;
  errors: string[] = [];
  footer: agFooter = new agFooter();
  @ViewChild('whId', { static: true }) whId: MatSelect;
  //#endregion

  constructor(private router: Router, private formbulider: FormBuilder,
    private svcSO: SOService, private svcToaster: agToasterService, private svcWaitDlg: WaitDialogService) {
  }

  ngOnInit() {
    this.frmSO = this.formbulider.group({
      whId: [null, [Validators.required]],
      storerKey: [null, [Validators.required]],
    });
    this.loadLookup();
    this.frmSO.disable();
    agFormHelper.setFormControls(this.optionName, agFormMode.Initialize);
    (<HTMLInputElement>document.getElementById("UploadFile")).disabled = true;
  }

  //#region toolbar functions
  tbAdd() {
    this.frmSO.reset();
    this.frmSO.enable();
    agFormHelper.setFormControls(this.optionName, agFormMode.Add);
    (<HTMLInputElement>document.getElementById("UploadFile")).disabled = false;
    this.whId.focus();
  }

  tbSave() {
    try {
      this.errors = [];
      this.frmSO.markAllAsTouched();
      if (!this.frmSO.invalid) {
        var formData: SO = this.frmSO.getRawValue();
        if (!formData.whId || !formData.storerKey) {
          this.svcToaster.showFailure("Please select valid Warehouse and enter Storer Key before uploading the file!");
        }
        if (!this.wipDocument) {
          this.svcToaster.showFailure("Please select valid file to be uploaded and then click Upload button")
          return;
        }
        let fileReader = new FileReader();
        fileReader.onload = (e) => {
          var arrayBuffer: any = fileReader.result;
          var data = new Uint8Array(arrayBuffer);
          var arr = new Array();
          for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
          var bstr = arr.join("");
          var workbook = xlsx.read(bstr, { type: "binary" });
          var first_sheet_name = workbook.SheetNames[0];
          var worksheet = workbook.Sheets[first_sheet_name];
          let jsonData: any[][] = xlsx.utils.sheet_to_json(worksheet, { raw: false, dateNF: "DD-MMM-YYYY", header: 1, defval: "" });
          if (jsonData.length < 1) {
            this.svcToaster.showFailure("No data found in your selected sheet, upload can't proceed further");
            return;
          }
          this.validateHeader(jsonData[0]); 
          if (this.errors.length > 0) {
            this.errors;
            return;
          }
          else {
            var sos: SO[] = this.getData(formData.storerKey, formData.whId, jsonData, jsonData[0].length);
            if (this.errors.length == 0)
              this.validate(sos);
            if (this.errors.length > 0) {
              this.errors;
              return;
            }
            else {
              if (sos.length == 0) {
                this.svcToaster.showWarning("There is no candidate row found in Excel sheet that could be uploaded to WMS, please recheck data in your sheet and retry!", "Data Missing");
                return;
              }
              this.svcWaitDlg.open({});
              this.svcSO.save(sos).subscribe(
                () => {
                  this.initForm();
                  agFormHelper.setFormControls(this.optionName, agFormMode.Initialize);
                  this.svcToaster.showSuccess('Upload request(s) created Successfully');
                },
                error => { this.svcToaster.showFailure(error); },
                () => { this.svcWaitDlg.close(); }
              );
            }
          }
        }
        fileReader.readAsArrayBuffer(this.wipDocument);
      }
    }
    catch (e) { this.svcWaitDlg.close(); this.svcToaster.showFailure(e); }
  }

  fileUpload(event) {
    this.wipDocument = event.target.files[0];
    if (!this.wipDocument) {
      this.svcToaster.showFailure("Please select valid file to be uploaded and then click Upload button")
      return;
    }
    if (this.wipDocument.size > 204800) {
      this.svcToaster.showFailure('Upload utility does not allow upload of file more than 200 KB. Please reduce file size and retry');
      return;
    }
  }

  tbUndo() {
    this.initForm();
    agFormHelper.setFormControls(this.optionName, agFormMode.Initialize);
  }

  tbExit() {
    this.router.navigate(['/MainForm']);
  }
  //#endregion toolbar functions

  //#region local functions
  getData(storerKey: string, whId: number, jsonData: any[][], headerLength: number) {
    this.errors = [];
    var sos: SO[] = [], extOrderNo = "", so: SO = new SO();
    for (let i = 1; i < jsonData.length; i++) {
      let currentRecord = jsonData[i];
      if (currentRecord.length >= headerLength) {
        if (currentRecord[0].trim() == "") {
          this.errors.push("row # " + (i + 1).toString() + " contains blank External Order Number, External Order Number is a key field and can't be left blank, upload process failed!");
          return;
        }
        if (extOrderNo != currentRecord[0].trim()) {
          if (so.details.length > 0) {
            sos.push(so);
          }
          so = new SO();
          so.storerKey = storerKey;
          so.whId = whId;
          extOrderNo = currentRecord[0].trim();
          so.externalOrderNo = extOrderNo;
          so.buyerPO = currentRecord[1].trim();
          so.orderGroup = currentRecord[2].trim();
          so.shipTo = currentRecord[3].trim();
          so.billTo = currentRecord[4].trim();
          so.deliveryDate = currentRecord[5].trim();
          so.udf1 = currentRecord[6].trim();
          so.udf2 = currentRecord[7].trim();
          so.udf3 = currentRecord[8].trim();
          so.udf4 = currentRecord[9].trim();
          so.udf5 = currentRecord[10].trim();
        }
        let sod: SODetail = new SODetail();
        sod.sku = currentRecord[11].trim();
        sod.uom = currentRecord[12].trim();
        sod.quantity = parseInt(currentRecord[13].trim());
        sod.lottable01 = currentRecord[14].trim();
        sod.lottable02 = currentRecord[15].trim();
        sod.lottable03 = currentRecord[16].trim();
        sod.lottable04 = currentRecord[17].trim();
        sod.lottable05 = currentRecord[18].trim();
        sod.lottable06 = currentRecord[19].trim();
        sod.lottable07 = currentRecord[20].trim();
        sod.lottable08 = currentRecord[21].trim();
        sod.lottable09 = currentRecord[22].trim();
        sod.lottable10 = currentRecord[23].trim();
        so.details.push(sod);
      }
    }
    if (so.details.length != 0)
      sos.push(so);
    return sos;
  }

  private loadLookup() {
    try {
      this.svcSO.getLookUp().subscribe(
        data => { this.lstWarehouse = data.lstWarehouse; },
        error => { this.svcToaster.showFailure(error); }
      );
    }
    catch (e) { this.svcToaster.showFailure(e); }
  }

  private validate(so: SO[]) {
    this.errors = [];
    if (so.some(x => x.externalOrderNo == "")) {
      this.errors.push('No row in SO Upload can have empty External Order #');
    }
    if (so.some(y => y.details.some(x => x.sku == ""))) {
      this.errors.push('No row in SO Upload can have empty Commodity');
    }
    if (so.some(y => y.details.some(x => x.uom == ""))) {
      this.errors.push('No row in SO Upload can have empty UOM');
    }
    if (so.some(y => y.details.some(x => !x.quantity || x.quantity <= 0))) {
      this.errors.push('The Quantity in each row must be greater than zero');
    }
  }

  private validateHeader(header: string[]) {
    this.errors = [];
    if (header[0].trim() != "External Order") {
      this.errors.push('External Order is a required field. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[1].trim() != "Buyer PO") {
      this.errors.push('Buyer PO column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[2].trim() != "Order Group") {
      this.errors.push('Order Group column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[3].trim() != "Ship To") {
      this.errors.push('Ship To column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[4].trim() != "Bill To") {
      this.errors.push('Bill To column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[5].trim() != "Delivery Date") {
      this.errors.push('Delivery Date column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[6].trim() != "User1") {
      this.errors.push('User1 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[7].trim() != "User2") {
      this.errors.push('User2 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[8].trim() != "User3") {
      this.errors.push('User3 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[9].trim() != "User4") {
      this.errors.push('User4 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[10].trim() != "User5") {
      this.errors.push('User5 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[11].trim() != "Sku") {
      this.errors.push('SKU column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[12].trim() != "UOM") {
      this.errors.push('UoM column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[13].trim() != "Qty") {
      this.errors.push('Expected Qty column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[14].trim() != "Lot1") {
      this.errors.push('Lot1 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[15].trim() != "Lot2") {
      this.errors.push('Lot2 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[16].trim() != "Lot3") {
      this.errors.push('Lot3 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[17].trim() != "Lot4") {
      this.errors.push('Lot4 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[18].trim() != "Lot5") {
      this.errors.push('Lot5 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[19].trim() != "Lot6") {
      this.errors.push('Lot6 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[20].trim() != "Lot7") {
      this.errors.push('Lot7 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[21].trim() != "Lot8") {
      this.errors.push('Lot8 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[22].trim() != "Lot9") {
      this.errors.push('Lot9 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
    if (header[23].trim() != "Lot10") {
      this.errors.push('Lot10 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
    }
  }

  private initForm() {
    this.frmSO.reset();
    this.frmSO.disable();
    this.errors = [];
    (<HTMLInputElement>document.getElementById("UploadFile")).disabled = true;
    (<HTMLInputElement>document.getElementById("UploadFile")).value = null;
  }
  //#endregion local functions
}
