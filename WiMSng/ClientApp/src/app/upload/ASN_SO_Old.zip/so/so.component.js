"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SOComponent = void 0;
const core_1 = require("@angular/core");
const forms_1 = require("@angular/forms");
const xlsx = require("xlsx");
const agFormHelper_1 = require("../../helper/agFormHelper");
const footer_1 = require("../../helper/footer");
const so_1 = require("./so");
const sodetail_1 = require("./sodetail");
let SOComponent = class SOComponent {
    //#endregion
    constructor(router, formbulider, svcSO, svcToaster, svcWaitDlg) {
        this.router = router;
        this.formbulider = formbulider;
        this.svcSO = svcSO;
        this.svcToaster = svcToaster;
        this.svcWaitDlg = svcWaitDlg;
        //#region form variables
        this.optionName = 'Shipment Order';
        this.errors = [];
        this.footer = new footer_1.agFooter();
    }
    ngOnInit() {
        this.frmSO = this.formbulider.group({
            whId: [null, [forms_1.Validators.required]],
            storerKey: [null, [forms_1.Validators.required]],
        });
        this.loadLookup();
        this.frmSO.disable();
        agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Initialize);
        document.getElementById("UploadFile").disabled = true;
    }
    //#region toolbar functions
    tbAdd() {
        this.frmSO.reset();
        this.frmSO.enable();
        agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Add);
        document.getElementById("UploadFile").disabled = false;
        this.whId.focus();
    }
    tbSave() {
        try {
            this.errors = [];
            this.frmSO.markAllAsTouched();
            if (!this.frmSO.invalid) {
                var formData = this.frmSO.getRawValue();
                if (!formData.whId || !formData.storerKey) {
                    this.svcToaster.showFailure("Please select valid Warehouse and enter Storer Key before uploading the file!");
                }
                if (!this.wipDocument) {
                    this.svcToaster.showFailure("Please select valid file to be uploaded and then click Upload button");
                    return;
                }
                let fileReader = new FileReader();
                fileReader.onload = (e) => {
                    var arrayBuffer = fileReader.result;
                    var data = new Uint8Array(arrayBuffer);
                    var arr = new Array();
                    for (var i = 0; i != data.length; ++i)
                        arr[i] = String.fromCharCode(data[i]);
                    var bstr = arr.join("");
                    var workbook = xlsx.read(bstr, { type: "binary" });
                    var first_sheet_name = workbook.SheetNames[0];
                    var worksheet = workbook.Sheets[first_sheet_name];
                    let jsonData = xlsx.utils.sheet_to_json(worksheet, { raw: false, dateNF: "DD-MMM-YYYY", header: 1, defval: "" });
                    if (jsonData.length < 1) {
                        this.svcToaster.showFailure("No data found in your selected sheet, upload can't proceed further");
                        return;
                    }
                    this.validateHeader(jsonData[0]);
                    if (this.errors.length > 0) {
                        this.errors;
                        return;
                    }
                    else {
                        var sos = this.getData(formData.storerKey, formData.whId, jsonData, jsonData[0].length);
                        if (this.errors.length == 0)
                            this.validate(sos);
                        if (this.errors.length > 0) {
                            this.errors;
                            return;
                        }
                        else {
                            if (sos.length == 0) {
                                this.svcToaster.showWarning("There is no candidate row found in Excel sheet that could be uploaded to WMS, please recheck data in your sheet and retry!", "Data Missing");
                                return;
                            }
                            this.svcWaitDlg.open({});
                            this.svcSO.save(sos).subscribe(() => {
                                this.initForm();
                                agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Initialize);
                                this.svcToaster.showSuccess('Upload request(s) created Successfully');
                            }, error => { this.svcToaster.showFailure(error); }, () => { this.svcWaitDlg.close(); });
                        }
                    }
                };
                fileReader.readAsArrayBuffer(this.wipDocument);
            }
        }
        catch (e) {
            this.svcWaitDlg.close();
            this.svcToaster.showFailure(e);
        }
    }
    fileUpload(event) {
        this.wipDocument = event.target.files[0];
        if (!this.wipDocument) {
            this.svcToaster.showFailure("Please select valid file to be uploaded and then click Upload button");
            return;
        }
        if (this.wipDocument.size > 204800) {
            this.svcToaster.showFailure('Upload utility does not allow upload of file more than 200 KB. Please reduce file size and retry');
            return;
        }
    }
    tbUndo() {
        this.initForm();
        agFormHelper_1.agFormHelper.setFormControls(this.optionName, agFormHelper_1.agFormMode.Initialize);
    }
    tbExit() {
        this.router.navigate(['/MainForm']);
    }
    //#endregion toolbar functions
    //#region local functions
    getData(storerKey, whId, jsonData, headerLength) {
        this.errors = [];
        var sos = [], extOrderNo = "", so = new so_1.SO();
        for (let i = 1; i < jsonData.length; i++) {
            let currentRecord = jsonData[i];
            if (currentRecord.length >= headerLength) {
                if (currentRecord[0].trim() == "") {
                    this.errors.push("row # " + (i + 1).toString() + " contains blank External Order Number, External Order Number is a key field and can't be left blank, upload process failed!");
                    return;
                }
                if (extOrderNo != currentRecord[0].trim()) {
                    if (so.details.length > 0) {
                        sos.push(so);
                    }
                    so = new so_1.SO();
                    so.storerKey = storerKey;
                    so.whId = whId;
                    extOrderNo = currentRecord[0].trim();
                    so.externalOrderNo = extOrderNo;
                    so.buyerPO = currentRecord[1].trim();
                    so.orderGroup = currentRecord[2].trim();
                    so.shipTo = currentRecord[3].trim();
                    so.billTo = currentRecord[4].trim();
                    so.deliveryDate = currentRecord[5].trim();
                    so.udf1 = currentRecord[6].trim();
                    so.udf2 = currentRecord[7].trim();
                    so.udf3 = currentRecord[8].trim();
                    so.udf4 = currentRecord[9].trim();
                    so.udf5 = currentRecord[10].trim();
                }
                let sod = new sodetail_1.SODetail();
                sod.sku = currentRecord[11].trim();
                sod.uom = currentRecord[12].trim();
                sod.quantity = parseInt(currentRecord[13].trim());
                sod.lottable01 = currentRecord[14].trim();
                sod.lottable02 = currentRecord[15].trim();
                sod.lottable03 = currentRecord[16].trim();
                sod.lottable04 = currentRecord[17].trim();
                sod.lottable05 = currentRecord[18].trim();
                sod.lottable06 = currentRecord[19].trim();
                sod.lottable07 = currentRecord[20].trim();
                sod.lottable08 = currentRecord[21].trim();
                sod.lottable09 = currentRecord[22].trim();
                sod.lottable10 = currentRecord[23].trim();
                so.details.push(sod);
            }
        }
        if (so.details.length != 0)
            sos.push(so);
        return sos;
    }
    loadLookup() {
        try {
            this.svcSO.getLookUp().subscribe(data => { this.lstWarehouse = data.lstWarehouse; }, error => { this.svcToaster.showFailure(error); });
        }
        catch (e) {
            this.svcToaster.showFailure(e);
        }
    }
    validate(so) {
        this.errors = [];
        if (so.some(x => x.externalOrderNo == "")) {
            this.errors.push('No row in SO Upload can have empty External Order #');
        }
        if (so.some(y => y.details.some(x => x.sku == ""))) {
            this.errors.push('No row in SO Upload can have empty Commodity');
        }
        if (so.some(y => y.details.some(x => x.uom == ""))) {
            this.errors.push('No row in SO Upload can have empty UOM');
        }
        if (so.some(y => y.details.some(x => !x.quantity || x.quantity <= 0))) {
            this.errors.push('The Quantity in each row must be greater than zero');
        }
    }
    validateHeader(header) {
        this.errors = [];
        if (header[0].trim() != "External Order") {
            this.errors.push('External Order is a required field. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[1].trim() != "Buyer PO") {
            this.errors.push('Buyer PO column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[2].trim() != "Order Group") {
            this.errors.push('Order Group column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[3].trim() != "Ship To") {
            this.errors.push('Ship To column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[4].trim() != "Bill To") {
            this.errors.push('Bill To column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[5].trim() != "Delivery Date") {
            this.errors.push('Delivery Date column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[6].trim() != "User1") {
            this.errors.push('User1 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[7].trim() != "User2") {
            this.errors.push('User2 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[8].trim() != "User3") {
            this.errors.push('User3 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[9].trim() != "User4") {
            this.errors.push('User4 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[10].trim() != "User5") {
            this.errors.push('User5 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[11].trim() != "Sku") {
            this.errors.push('SKU column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[12].trim() != "UOM") {
            this.errors.push('UoM column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[13].trim() != "Qty") {
            this.errors.push('Expected Qty column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[14].trim() != "Lot1") {
            this.errors.push('Lot1 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[15].trim() != "Lot2") {
            this.errors.push('Lot2 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[16].trim() != "Lot3") {
            this.errors.push('Lot3 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[17].trim() != "Lot4") {
            this.errors.push('Lot4 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[18].trim() != "Lot5") {
            this.errors.push('Lot5 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[19].trim() != "Lot6") {
            this.errors.push('Lot6 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[20].trim() != "Lot7") {
            this.errors.push('Lot7 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[21].trim() != "Lot8") {
            this.errors.push('Lot8 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[22].trim() != "Lot9") {
            this.errors.push('Lot9 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
        if (header[23].trim() != "Lot10") {
            this.errors.push('Lot10 column does not exists or out of position. Please note that system is mapped one-to-one with these columns so ensure you are refering to Excel file containing exact same column headings and position');
        }
    }
    initForm() {
        this.frmSO.reset();
        this.frmSO.disable();
        this.errors = [];
        document.getElementById("UploadFile").disabled = true;
        document.getElementById("UploadFile").value = null;
    }
};
__decorate([
    core_1.ViewChild('whId', { static: true })
], SOComponent.prototype, "whId", void 0);
SOComponent = __decorate([
    core_1.Component({
        selector: 'app-so',
        templateUrl: './so.component.html',
        styleUrls: ['./so.component.css']
    })
], SOComponent);
exports.SOComponent = SOComponent;
//# sourceMappingURL=so.component.js.map