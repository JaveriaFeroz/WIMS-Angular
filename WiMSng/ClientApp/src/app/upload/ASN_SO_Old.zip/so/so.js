"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SO = void 0;
class SO {
    constructor() {
        this.details = [];
    }
}
exports.SO = SO;
//# sourceMappingURL=so.js.map