import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { SO } from './so';
@Injectable({ providedIn: 'root' })

export class SOService {
  apiURL: string;
  constructor(private http: HttpClient, @Inject('API_BASE_URL') baseUrl: string) {
    this.apiURL = baseUrl;
  }

  getLookUp() {
    return this.http.get<any>(this.apiURL + 'upload/SO/GetLookups');
  }

  save(so: SO[]) {
    return this.http.post<SO>(this.apiURL + 'upload/SO/', so);
  }
}
